(async function(){
  /* ============================================================
     常量 & 全局状态
     ============================================================ */
  const ACTIVE_KEY = 'chatReaderActiveId_v30';
  const LEARN_KEY = 'chatReaderLearn_v30';
  const SETTINGS_KEY = 'chatReaderSettings_v30';
  const AI_KEY = 'chatReaderAiConfig_v30';

  let library = { books: [] };
  let activeBook = null;
  let learnData = { denyWords: [] };
  let settings = { minLen: 12, maxLen: 42 };
  let aiConfig = { url: '', key: '', model: '', enabled: false, scope: 'all' };
  let currentFilter = null;
  let readTimer = null;

  /* 撤回栈：每项 {bookId, snapshot, timestamp, desc} */
  let renameHistory = [];

  /* ============================================================
     IndexedDB 存储层
     ============================================================ */
  let db;
  async function initDB() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open('ChatReaderDB', 1);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains('store')) {
          db.createObjectStore('store');
        }
      };
      req.onsuccess = (e) => { db = e.target.result; resolve(); };
      req.onerror = (e) => reject(e);
    });
  }
  async function dbSet(key, val) {
    return new Promise((resolve, reject) => {
      const tx = db.transaction('store', 'readwrite');
      const store = tx.objectStore('store');
      const req = store.put(val, key);
      req.onsuccess = () => resolve();
      req.onerror = (e) => reject(e);
    });
  }
  async function dbGet(key) {
    return new Promise((resolve, reject) => {
      const tx = db.transaction('store', 'readonly');
      const store = tx.objectStore('store');
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result);
      req.onerror = (e) => reject(e);
    });
  }

  /* 旧书迁移：升级前导入的书视为“高置信度=已校对”，避免升级后重复消耗额度。
     新版本导入的书带 aiV2 标记，不受影响（每一句都会交给 AI 判断）。 */
  function migrateLegacyAiMarks(book){
    if(!book || book.aiV2) return;
    book.parsedLines.forEach(l=>{
      if(l.type === 'dialogue' && l.aiChecked === undefined && !l.userFixed && l.confidence === 'high'){
        l.aiChecked = true;
      }
    });
    book.aiV2 = true;
  }

  async function loadStorage() {
    try {
      const lib = await dbGet('library');
      if (lib) library = lib;
      if (!library.books) library.books = [];
      library.books.forEach(migrateLegacyAiMarks);

      const ld = await dbGet('learnData');
      if (ld) learnData = ld;
      if (!Array.isArray(learnData.denyWords)) learnData.denyWords = [];

      const st = await dbGet('settings');
      if (st) settings = st;

      const ai = localStorage.getItem(AI_KEY);
      if (ai) aiConfig = JSON.parse(ai);
      if(!aiConfig.scope) aiConfig.scope = 'all';

      const activeId = localStorage.getItem(ACTIVE_KEY);
      if (activeId) {
        const book = library.books.find(b => b.id === activeId);
        if (book) activeBook = book;
      }
    } catch (e) {
      console.error('加载数据失败', e);
    }
  }

  function saveLibrary() { dbSet('library', library).catch(e => console.error(e)); }
  function saveLearn() { dbSet('learnData', learnData).catch(e => console.error(e)); }
  function saveSettings() { dbSet('settings', settings).catch(e => console.error(e)); }
  function saveAiConfig() { localStorage.setItem(AI_KEY, JSON.stringify(aiConfig)); }
  function setActiveId(id) { try{ localStorage.setItem(ACTIVE_KEY, id); }catch(e){} }
  function genId(){ return 'book_' + Date.now() + '_' + Math.random().toString(36).slice(2,7); }

  /* ============================================================
     计时器
     ============================================================ */
  function startReadTimer(){
    stopReadTimer();
    if(!activeBook) return;
    if(!activeBook.readTime) activeBook.readTime = 0;
    let sessionStart = Date.now();

    function tick(){
      if(document.visibilityState === 'visible' && activeBook){
        const now = Date.now();
        const delta = now - sessionStart;
        if(delta > 0) activeBook.readTime += delta;
        sessionStart = now;
        saveLibrary();
        if(shelfModal.classList.contains('show')) renderShelf();
      }
    }
    readTimer = setInterval(tick, 30000);
    document.addEventListener('visibilitychange', ()=>{
      if(document.visibilityState === 'hidden') tick();
      else sessionStart = Date.now();
    });
  }
  function stopReadTimer(){
    if(readTimer) clearInterval(readTimer);
    readTimer = null;
  }
  function formatTime(ms){
    if(!ms) return '0m';
    const mins = Math.floor(ms / 60000);
    if(mins < 60) return mins + 'm';
    const hours = Math.floor(mins / 60);
    const rem = mins % 60;
    return hours + 'h ' + rem + 'm';
  }

  /* ============================================================
     编码检测
     ============================================================ */
  async function readTextFileSmart(file, forcedEncoding){
    const buffer = await file.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    if(forcedEncoding && forcedEncoding !== 'auto'){
      try{ return { text: new TextDecoder(forcedEncoding).decode(buffer), encoding: forcedEncoding }; }catch(e){}
    }
    if(bytes.length >= 3 && bytes[0]===0xEF && bytes[1]===0xBB && bytes[2]===0xBF){
      return { text: new TextDecoder('utf-8').decode(buffer), encoding: 'UTF-8 (BOM)' };
    }
    if(bytes.length >= 2 && bytes[0]===0xFF && bytes[1]===0xFE){
      return { text: new TextDecoder('utf-16le').decode(buffer), encoding: 'UTF-16 LE' };
    }
    if(bytes.length >= 2 && bytes[0]===0xFE && bytes[1]===0xFF){
      return { text: new TextDecoder('utf-16be').decode(buffer), encoding: 'UTF-16 BE' };
    }
    function countReplacement(t){ return (t.match(/\uFFFD/g) || []).length; }
    let utf8Text = null, gbText = null;
    try{ utf8Text = new TextDecoder('utf-8').decode(buffer); }catch(e){}
    try{ gbText = new TextDecoder('gb18030').decode(buffer); }catch(e){}
    const utf8Bad = utf8Text !== null ? countReplacement(utf8Text) : Infinity;
    const gbBad = gbText !== null ? countReplacement(gbText) : Infinity;
    if(utf8Text !== null && utf8Bad <= gbBad){
      return { text: utf8Text, encoding: utf8Bad === 0 ? 'UTF-8' : 'UTF-8（有少量坏字符）' };
    }
    if(gbText !== null){
      return { text: gbText, encoding: gbBad === 0 ? 'GB18030/GBK' : 'GB18030（有少量坏字符）' };
    }
    return { text: new TextDecoder('utf-8').decode(buffer), encoding: 'UTF-8（强制）' };
  }

  /* ============================================================
     DOM
     ============================================================ */
  const messagesArea = document.getElementById('messagesArea');
  const roleSelect = document.getElementById('roleSelect');
  const tapHint = document.getElementById('tapHint');
  const backToLatest = document.getElementById('backToLatest');
  const progressBadge = document.getElementById('progressBadge');
  const bookTitleEl = document.getElementById('bookTitle');
  const toastEl = document.getElementById('toast');
  const modalOverlay = document.getElementById('modalOverlay');

  const aiModal = document.getElementById('aiModal');
  const aiUrl = document.getElementById('aiUrl');
  const aiKey = document.getElementById('aiKey');
  const aiModel = document.getElementById('aiModel');
  const aiEnable = document.getElementById('aiEnable');
  const aiBtn = document.getElementById('aiBtn');
  const aiClose = document.getElementById('aiClose');
  const aiCancel = document.getElementById('aiCancel');
  const aiSave = document.getElementById('aiSave');
  const aiScope = document.getElementById('aiScope');
  const aiCheckAllBtn = document.getElementById('aiCheckAllBtn');
  const aiResetBtn = document.getElementById('aiResetBtn');
  const aiStatus = document.getElementById('aiStatus');

  const annotationModal = document.getElementById('annotationModal');
  const annotationPreview = document.getElementById('annotationPreview');
  const annotationInput = document.getElementById('annotationInput');
  const annotationClose = document.getElementById('annotationClose');
  const annotationCancel = document.getElementById('annotationCancel');
  const annotationSave = document.getElementById('annotationSave');
  const annotationCopy = document.getElementById('annotationCopy');
  let currentAnnotatingElement = null;
  let currentAnnotatingId = null;
  let currentAnnotatingText = '';

  const importModal = document.getElementById('importModal');
  const importTitle = document.getElementById('importTitle');
  const fileInput = document.getElementById('fileInput');
  const importTextarea = document.getElementById('importTextarea');
  const importBtn = document.getElementById('importBtn');
  const importClose = document.getElementById('importClose');
  const importCancel = document.getElementById('importCancel');
  const importConfirm = document.getElementById('importConfirm');
  const encodingSelect = document.getElementById('encodingSelect');

  const shelfModal = document.getElementById('shelfModal');
  const shelfList = document.getElementById('shelfList');
  const charManageList = document.getElementById('charManageList');
  const cleanupBtn = document.getElementById('cleanupBtn');
  const shelfBtn = document.getElementById('shelfBtn');
  const shelfClose = document.getElementById('shelfClose');
  const exportBtn = document.getElementById('exportBtn');
  const exportBookBtn = document.getElementById('exportBookBtn');
  const exportAnnoBtn = document.getElementById('exportAnnoBtn');
  const importArchiveInput = document.getElementById('importArchiveInput');
  const learnStats = document.getElementById('learnStats');
  const clearLearnBtn = document.getElementById('clearLearnBtn');
  const minLenInput = document.getElementById('minLenInput');
  const maxLenInput = document.getElementById('maxLenInput');
  const aliasList = document.getElementById('aliasList');
  const aliasFrom = document.getElementById('aliasFrom');
  const aliasTo = document.getElementById('aliasTo');
  const aliasAddBtn = document.getElementById('aliasAddBtn');

  const chapterModal = document.getElementById('chapterModal');
  const chapterList = document.getElementById('chapterList');
  const chapterClose = document.getElementById('chapterClose');

  const annoBtn = document.getElementById('annoBtn');
  const annoBadge = document.getElementById('annoBadge');
  const annoListModal = document.getElementById('annoListModal');
  const annoList = document.getElementById('annoList');
  const annoListClose = document.getElementById('annoListClose');

  const filterBtn = document.getElementById('filterBtn');
  const filterModal = document.getElementById('filterModal');
  const filterList = document.getElementById('filterList');
  const filterClose = document.getElementById('filterClose');
  const filterClear = document.getElementById('filterClear');

  const fixModal = document.getElementById('fixModal');
  const fixOldName = document.getElementById('fixOldName');
  const fixLowConf = document.getElementById('fixLowConf');
  const fixNewName = document.getElementById('fixNewName');
  const fixNote = document.getElementById('fixNote');
  const fixCancel = document.getElementById('fixCancel');
  const fixThisOnly = document.getElementById('fixThisOnly');
  const fixAllInBook = document.getElementById('fixAllInBook');
  let fixingLineData = null;
  let fixingNameSpan = null;
  let fixingRow = null;

  const undoBtn = document.getElementById('undoBtn');

  const NEAR_BOTTOM_THRESHOLD = 80;

  /* ============================================================
     通用 UI
     ============================================================ */
  function toast(msg){
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastEl._t);
    toastEl._t = setTimeout(()=>toastEl.classList.remove('show'), 1800);
  }
  function isNearBottom(){
    const a = messagesArea;
    return a.scrollHeight - a.scrollTop - a.clientHeight < NEAR_BOTTOM_THRESHOLD;
  }
  function scrollToBottom(smooth=true){
    messagesArea.scrollTo({top: messagesArea.scrollHeight, behavior: smooth?'smooth':'auto'});
  }
  function openSheet(el){ el.classList.add('show'); modalOverlay.classList.add('show'); }
  function closeSheet(el){ el.classList.remove('show'); if(!document.querySelector('.sheet.show') && !fixModal.classList.contains('show')) modalOverlay.classList.remove('show'); }
  function closeAllSheets(){
    [annotationModal, importModal, shelfModal, chapterModal, annoListModal, filterModal, aiModal].forEach(m=>m.classList.remove('show'));
    fixModal.classList.remove('show');
    modalOverlay.classList.remove('show');
  }

  function resolveSpeaker(raw){
    if(!raw || !activeBook || !activeBook.aliases) return raw;
    return activeBook.aliases[raw] || raw;
  }

  /* ============================================================
     否决词
     ============================================================ */
  const BASE_DENY_WORDS = [
    '说','道','问','答','喊','叫','嚷','讲','告诉','解释','补充','开口','插嘴','追问','反问',
    '夸赞','称赞','夸奖','赞叹','附和','认同','感慨','感叹','嘀咕','嘟囔','低语','自语',
    '笑道','哭道','骂道','叹道','怒道','回道','应道','答道','问道','说道','喊道','叫道','嚷道',
    '笑','哭','骂','叹','怒','回答','回应','念叨','埋怨','抱怨','吐槽','调侃','打趣','嘲讽',
    '低声','高声','轻声','大声','小声','沉声','柔声','冷声',
    '听到','看到','想到','感到','觉得','发现','意识','感觉','知道','明白','记得','忘了','想起','回忆',
    '心想','暗想','寻思','琢磨',
    '一句','两句','一声','两声','几句','一番','一下','一次','一句句','一声声',
    '了一句','了两句','了一声','了两声','了几句','了一番','了一下','了一次',
    '这','那','此','该','这个','那个','这些','那些','这样','那样','这里','那里',
    '他们','她们','我们','你们','大家','众人','有人','别人','对方','双方','旁人',
    '然后','接着','随即','于是','这时','那时','此时','此刻','之后','随后','最后','终于',
    '心里','心中','内心','脸上','眼中','眼里','嘴里','口中','手上','手中',
    '违心','违心地','无奈','无奈地','勉强','勉强地','不情愿','不情愿地','尴尬','尴尬地',
    '名字','名字时','这名字','那名字','声音','语气','话','话时','时候','片刻','瞬间',
    '撬开','推开','打开','关上','合上','拉上','拉开','放下','拿起','抬起','举起','扔下','捡起',
    '瞟了眼','看了一眼','瞧了眼','望了眼','瞥了眼','扫了眼',
    '松了一口','松了一口气','叹了口气','吸了口气','呼了口气','喘了口气','缓了口气',
    '摇了摇头','点了点头','皱了皱眉','笑了笑','哭了出来','喊了出来','叫了出来',
    '转过头','扭过头','回过头','低下头','抬起头','偏过头','侧过头','转过脸','转过身子',
    '站起身','坐起身','站起来','坐下来','躺下来','蹲下来','跪下来','趴下来',
    '伸出手','收回手','抬起手','放下手','握住手','松开手','拍了拍','摸了摸','碰了碰',
    '抿了抿嘴','张了张嘴','咬了咬牙','跺了跺脚','拍了拍手','搓了搓手',
    '走进来','走出去','跑进来','跑出去','冲进来','冲出去','退出去','退回来',
    '愣了三秒','愣了愣','呆了一呆','怔了怔','顿了顿','停了停','想了想','看了看','听了听',
    '沉默片刻','沉默了一瞬','沉默了一会儿','犹豫了一下','迟疑了一下','停顿了一下',
    '压低声音','提高声音','放低声音','放轻声音',
    '缓缓','缓缓地','慢慢','慢慢地','轻轻','轻轻地','悄悄','悄悄地','默默','默默地',
    '突然','忽然','猛然','骤然','立刻','马上','顿时','随即','接着','然后','于是',
    '明显','显然','似乎','好像','仿佛','大概','也许','应该','正在','已经','曾经','一直','总是',
    '只','才','又','也','还','都','很','太','更','最','不','没','别','莫','却','便','就','正','已','曾','将',
    '黑暗','光明','门口','房间','窗户','窗外','街道','天空','地面','空气','阳光','月光','灯光',
    '目光','眼神','脸色','表情','面容','脸庞','嘴角','眉头','眼睛','鼻子','嘴巴','耳朵',
    '手臂','手指','手掌','脚步','身影','背影','身体','脑袋','脖子','肩膀','胸口','肚子',
    '屋里','屋外','门外','门内','楼上','楼下','前面','后面','旁边','对面','里面','外面',
    '此刻','此时','现在','当时','刚才','之前','以后','以前','身后','身前','暗中','周围','四周',
    '手势','动作','姿态','模样','样子','神情','神色','视线','声音','语气','口吻',
    '伸手','抬手','缩手','收手','摆手','挥手','招手','拱手','抱拳','叉腰','抱臂','摊手',
    '拽他','拽你','拽我','拽住','拉住','抓住','扯住','按住','抱住','扶住','拦住','挡住',
    '推他','推你','推我','推开','拉开','扯开','掀开','踢开','踹开','砸开','劈开',
    '看他','看你','看我','看她','瞧他','瞧你','瞧我','望他','望你','望我',
    '听他','听你','听我','问她','问他','问我','答他','答你','答我',
    '摇头','点头','皱眉','叹气','冷笑','苦笑','微笑','大笑','怒笑',
    '转身','回头','低头','抬头','偏头','侧头','起身','坐下','站起','躺下','蹲下','跪下','趴下',
    '声大','讥甩','大吼','大叫','大喊','低吼','怒喝','冷笑','嗤笑','苦笑'
  ];

  let runtimeDenySet = new Set();
  function rebuildDenySet(){
    runtimeDenySet = new Set(BASE_DENY_WORDS);
    learnData.denyWords.forEach(w => runtimeDenySet.add(w));
  }

  /* ============================================================
     说话后缀剥离（问题4：说字型即时处理）
     ============================================================ */
  const SPEECH_SUFFIXES = [
    '说道','问道','答道','喊道','叫道','嚷道','笑道','哭道','骂道','叹道','怒道','回道','应道',
    '说','道','问','答','喊','叫','嚷','讲','谈','吼','喝','骂','叹','笑','哭',
    '说着','道着','问着','答着',
    '地说','地道','地问','地答','地喊',
    '开口','插嘴','追问','反问','回答','回应'
  ];

  function stripSpeechSuffix(name){
    if(!name) return name;
    for(const suf of SPEECH_SUFFIXES){
      if(name.length > suf.length && name.endsWith(suf)){
        const core = name.slice(0, name.length - suf.length);
        if(core.length >= 2 && /^[\u4e00-\u9fa5]+$/.test(core)){
          return core;
        }
      }
    }
    return name;
  }

  // ABC 包含已知 AB → 归并到 AB（问题3）
  function collapseToKnown(name, knownSet){
    if(!name || !knownSet || knownSet.size === 0) return name;
    if(knownSet.has(name)) return name;
    let best = null;
    for(const k of knownSet){
      if(k.length >= 2 && name.includes(k) && name !== k){
        if(!best || k.length > best.length) best = k;
      }
    }
    return best || name;
  }

  /* ============================================================
     说话人识别
     ============================================================ */
  const SAY_VERBS = '说道|说|道|问|答|喊|叫|嚷|嘟囔|嘀咕|笑道|哭道|骂道|叹道|低声道|大声道|沉声道|柔声道|回答道|应道|问道|喊道|叫道|开口|插嘴|追问|反问|告诉|解释|补充|念叨|埋怨|抱怨|吐槽|调侃|打趣|嘲讽|夸赞|称赞|夸奖|赞叹|附和|认同|感慨|感叹|回答|回应|追着说';
  const BAD_ENDINGS = /[了着过得的]$/;
  const PRONOUNS = new Set(['他','她','它','你','我','咱','俺','他们','她们','我们','你们','大家','众人','有人','别人','对方','双方','旁人']);
  const NEGATIVE_STARTS = /^(没|不|无|别|莫)/;
  const PREDICATE_STARTS = /^(说|道|问|答|喊|叫|嚷|讲|告诉|解释|补充|开口|插嘴|追问|反问|笑道|哭道|骂道|叹道|回答|回应|念叨|埋怨|抱怨|吐槽|调侃|打趣|嘲讽|夸赞|称赞|夸奖|赞叹|附和|认同|感慨|感叹|想|心想|暗想|寻思|琢磨|觉得|感到|发现|意识|知道|明白|记得|忘了|想起|回忆|看|望|瞧|瞥|瞟|扫|盯|听|闻|做|走|跑|站|坐|躺|蹲|跪|趴|靠|转|回|抬|低|伸|收|握|松|拍|摸|碰|推|拉|打|开|关|拿|放|扔|捡|朝|向|对|跟|和|与|同|笑|哭|骂|叹|怒|愣|呆|怔|顿|停|沉默|犹豫|迟疑|停顿|压|提|放|轻|缓缓|慢慢|轻轻|悄悄|默默|突然|忽然|猛然|骤然|立刻|马上|顿时|随即|接着|然后|于是|只是|却|便|就|正|在|已|曾|将|要|会|能|可|敢|肯|愿|明显|显然|似乎|好像|仿佛|大概|也许|应该|正在|已经|曾经|一直|总是|只|才|又|也|还|都|很|太|更|最|不|没|别|莫)/;
  const ACTION_PHRASE_SET = new Set(BASE_DENY_WORDS);
  const BAD_STARTS = /^[了着过得的把被将给向对跟和与同在从到于为以因由]/;

  function isLikelyName(name){
    if(!name) return false;
    if(name.length < 2 || name.length > 4) return false;
    if(runtimeDenySet.has(name)) return false;
    if(BAD_ENDINGS.test(name)) return false;
    if(name.includes('的')) return false;
    if(PRONOUNS.has(name)) return false;
    if(NEGATIVE_STARTS.test(name)) return false;
    if(BAD_STARTS.test(name)) return false;
    if(ACTION_PHRASE_SET.has(name)) return false;
    // 问题4：以说话动词结尾的，不当人名（交给 stripSpeechSuffix 剥离）
    if(SPEECH_SUFFIXES.some(s => name.length > s.length && name.endsWith(s))) return false;
    return true;
  }

  function findSubjectInClause(clause, knownSet){
    if(!clause) return null;
    for(let i = 0; i < clause.length - 1; i++){
      if(i > 0){
        const prev = clause[i-1];
        if('的地得在把将被给向对跟和与同从到于为以因由'.includes(prev)) continue;
      }
      for(const len of [2,3,4]){
        if(i + len >= clause.length) continue;
        const cand = clause.slice(i, i+len);
        if(!/^[\u4e00-\u9fa5]+$/.test(cand)) continue;
        if(knownSet && knownSet.has(cand)) return cand;
        if(!isLikelyName(cand)) continue;
        const rest = clause.slice(i + len);
        if(!PREDICATE_STARTS.test(rest)) continue;
        return cand;
      }
    }
    return null;
  }

  function findKnownCharacter(text, knownSet){
    if(!text || !knownSet || knownSet.size === 0) return null;
    let bestMatch = null;
    let bestPos = -1;
    for(const name of knownSet){
      const pos = text.lastIndexOf(name);
      if(pos > bestPos){
        bestPos = pos;
        bestMatch = name;
      }
    }
    return bestMatch;
  }

  function extractSpeaker(before, after, bookNameFix, knownCharacters, fullParagraph){
    const fix = bookNameFix || {};
    const wrap = (name, conf) => {
      if(!name) return null;
      name = stripSpeechSuffix(name);           // 问题4：剥离说话后缀
      const isKnown = knownCharacters && knownCharacters.has(name);
      if(!isKnown && !isLikelyName(name)) return null;
      if(fix[name]) return { name: fix[name], confidence: conf };
      return { name, confidence: conf };
    };

    // 前面是“xx：”结尾且包含已知角色
    if(before && /[：:]\s*$/.test(before)){
      const text = before.slice(0, -1).trim();
      const known = findKnownCharacter(text, knownCharacters);
      if(known){
        const r = wrap(known, 'high');
        if(r) return r;
      }
    }

    if(before){
      let mm = before.match(new RegExp('([\\u4e00-\\u9fa5]{2,4})\\s*(?:' + SAY_VERBS + ')\\s*[：:]\\s*$'));
      if(mm){ const r = wrap(mm[1], 'high'); if(r) return r; }
      for(const len of [4,3,2]){
        const re = new RegExp('([\\u4e00-\\u9fa5]{' + len + '})\\s*[：:]\\s*$');
        const m = before.match(re);
        if(m){
          const namePos = before.lastIndexOf(m[1]);
          const prevChar = namePos > 0 ? before[namePos - 1] : '';
          if(prevChar && !/[，。！？；：、\s\n]/.test(prevChar)) continue;
          const r = wrap(m[1], 'high'); if(r) return r;
        }
      }
      if(/[：:]\s*$/.test(before)){
        const text = before.slice(0, -1).trim();
        const known = findKnownCharacter(text, knownCharacters);
        if(known){ const r = wrap(known, 'medium'); if(r) return r; }
      }
      if(fullParagraph){
        const narrationText = fullParagraph.replace(/[“"「『][^”"」』]*[”"」』]/g, '');
        const known = findKnownCharacter(narrationText, knownCharacters);
        if(known){ const r = wrap(known, 'medium'); if(r) return r; }
      }
      if(/[：:]\s*$/.test(before)){
        const text = before.slice(0, -1);
        const clauses = text.split(/[，。！？；、]/).map(s=>s.trim()).filter(s=>s.length>0);
        for(let i = clauses.length - 1; i >= 0; i--){
          const subj = findSubjectInClause(clauses[i], knownCharacters);
          if(subj){ const r = wrap(subj, 'low'); if(r) return r; }
        }
      }
    }

    if(after){
      let mm = after.match(new RegExp('^([\\u4e00-\\u9fa5]{2,4})\\s*(?:' + SAY_VERBS + ')'));
      if(mm){ const r = wrap(mm[1], 'high'); if(r) return r; }
      mm = after.match(new RegExp('^([\\u4e00-\\u9fa5]{2,4})\\s*[，,、]\\s*(?:' + SAY_VERBS + ')'));
      if(mm){ const r = wrap(mm[1], 'high'); if(r) return r; }
      const firstClause = after.split(/[。！？；\n]/)[0].trim();
      if(firstClause){
        const subj = findSubjectInClause(firstClause, knownCharacters);
        if(subj){ const r = wrap(subj, 'low'); if(r) return r; }
      }
    }

    return null;
  }

  /* ============================================================
     解析
     ============================================================ */
  const chapterTitleRegex = /^\s*(第[一二三四五六七八九十百千零〇两0-9]+[章节回卷篇部]|Chapter\s+[0-9IVXLCDM]+|序章|楔子|尾声|后记|终章|番外)/i;

  function parseBook(text, existingNameFix){
    rebuildDenySet();
    const nameFix = existingNameFix || {};
    const parsedLines = [];
    const chapters = [];
    const charSet = new Set();
    const recentSpeakers = [];
    let id = 0;

    function splitNarration(raw){
      if(!raw) return [];
      const sentences = [];
      let buf = '';
      let inQuote = false;
      for(let i = 0; i < raw.length; i++){
        const ch = raw[i];
        buf += ch;
        if('“"「『'.includes(ch)) inQuote = true;
        else if('”"」』'.includes(ch) && inQuote) inQuote = false;
        if(!inQuote && '。！？；'.includes(ch)){
          sentences.push(buf); buf = '';
        }
      }
      if(buf.trim()) sentences.push(buf);
      const MIN_LEN = settings.minLen;
      const TARGET_MAX = settings.maxLen;
      const merged = [];
      let pending = '';
      for(const s of sentences){
        const t = (pending + s).trim();
        if(!t) continue;
        if(t.length < MIN_LEN){ pending = t; }
        else{
          if(pending && (pending + t).length <= TARGET_MAX){
            merged.push(pending + t); pending = '';
          }else{
            if(pending){ merged.push(pending); pending = ''; }
            merged.push(t);
          }
        }
      }
      if(pending) merged.push(pending);
      return merged.length > 0 ? merged : [raw];
    }
    function pushNarration(t){
      if(!t) return;
      const parts = splitNarration(t);
      for(const part of parts){
        if(part.trim()) parsedLines.push({type:'narration', speaker:'旁白', text:part.trim(), id:id++});
      }
    }

    const rawParas = text.split(/\n+/).map(s=>s.trim()).filter(s=>s.length>0);
    const quoteRegex = /[“"「『]([^”"」』]*)[”"」』]/g;

    for(const para of rawParas){
      if(chapterTitleRegex.test(para)){
        chapters.push({ title: para.slice(0, 40), startIndex: parsedLines.length });
        parsedLines.push({ type:'narration', speaker:'旁白', text: para, id: id++, isChapter:true });
        continue;
      }

      const matches = [...para.matchAll(quoteRegex)];
      if(matches.length === 0){
        pushNarration(para);
        continue;
      }

      let cursor = 0;
      for(let mi = 0; mi < matches.length; mi++){
        const m = matches[mi];
        const quoteStart = m.index;
        const quoteEnd = m.index + m[0].length;
        const dialogueText = m[1].trim();

        const before = para.slice(cursor, quoteStart).trim();
        const nextQuoteStart = (mi + 1 < matches.length) ? matches[mi+1].index : para.length;
        const after = para.slice(quoteEnd, nextQuoteStart).trim();

        if(before){ pushNarration(before); }

        const result = extractSpeaker(before, after, nameFix, charSet, para);

        let speaker, confidence;
        if(result){
          speaker = result.name;
          confidence = result.confidence;
        }else{
          if(recentSpeakers.length > 0){
            speaker = recentSpeakers[recentSpeakers.length - 1];
            confidence = 'medium';
          }else if(charSet.size > 0){
            speaker = [...charSet].pop();
            confidence = 'medium';
          }else{
            speaker = '？？？';
            confidence = 'high';
          }
        }

        // 问题3：ABC 包含已知 AB → 归并
        if(speaker && speaker !== '？？？'){
          speaker = collapseToKnown(speaker, charSet);
        }

        if(speaker && speaker !== '？？？'){
          if(confidence !== 'low'){
            charSet.add(speaker);
          }
          recentSpeakers.push(speaker);
        }

        parsedLines.push({ type:'dialogue', speaker, text: dialogueText, id: id++, confidence });
        cursor = quoteEnd;
      }

      const after = para.slice(cursor).trim();
      if(after){ pushNarration(after); }
    }

    let characters = [...charSet];
    if(characters.length === 0) characters.push('未知角色');
    return { parsedLines, characters, chapters };
  }

  /* ============================================================
     AI 纠错引擎（批量 · 跟随阅读进度）
     ============================================================ */
  const AI_BATCH = 14;          // 每批最多判断的对话条数
  const AI_CONTEXT = 10;        // 每批前带上文的条数
  const AI_WINDOW_AHEAD = 40;   // 跟随进度：优先判断当前进度往后这么多条内的对话
  const AI_DEBOUNCE = 700;      // 连续点按合并请求（毫秒）

  let aiBusy = false;           // 是否有请求在途
  let aiTimer = null;           // 防抖计时器
  let aiSweepAll = false;       // 是否处于“校对全书”模式
  let aiFailCount = 0;          // 连续失败计数
  let aiPaused = false;         // 连续失败后暂停，等用户操作再试

  // 这条对话是否需要 AI 判断
  function aiLineNeedsCheck(l){
    if(l.type !== 'dialogue') return false;
    if(l.userFixed || l.aiChecked) return false;
    if(aiConfig.scope !== 'all'){
      if(l.confidence === 'high' && l.speaker !== '？？？' && l.speaker !== '未知角色' && l.speaker !== '') return false;
    }
    return true;
  }

  // 找到下一批的起点下标；没有则返回 -1
  function aiGetCandidates(){
    if(!activeBook || !aiConfig.enabled || !aiConfig.url || !aiConfig.key || !aiConfig.model) return -1;
    const lines = activeBook.parsedLines;
    if(aiSweepAll){
      for(let i = 0; i < lines.length; i++) if(aiLineNeedsCheck(lines[i])) return i;
      aiSweepAll = false;
      return -1;
    }
    // 跟随阅读进度：处理“刚读过的几条 + 往后 AI_WINDOW_AHEAD 条”
    const start = Math.max(0, activeBook.currentIndex - AI_CONTEXT);
    const end = Math.min(lines.length, activeBook.currentIndex + AI_WINDOW_AHEAD);
    for(let i = start; i < end; i++) if(aiLineNeedsCheck(lines[i])) return i;
    return -1;
  }

  function scheduleAiCheck(immediate){
    if(!aiConfig.enabled || !activeBook) return;
    if(aiBusy) return;   // 在途请求完成后会自动接续
    aiPaused = false;    // 用户操作重新触发 → 恢复
    aiFailCount = 0;
    if(aiTimer){ clearTimeout(aiTimer); aiTimer = null; }
    if(immediate){ runAiBatch(); return; }
    aiTimer = setTimeout(()=>{ aiTimer = null; runAiBatch(); }, AI_DEBOUNCE);
  }

  function updateAiStatus(){
    const el = aiStatus;
    if(!el) return;
    if((aiBusy || aiTimer) && activeBook){
      if(aiSweepAll){
        let done = 0, total = 0;
        for(const l of activeBook.parsedLines){
          if(l.type !== 'dialogue') continue;
          total++;
          if(l.aiChecked || l.userFixed) done++;
        }
        el.textContent = `✨ 校对全书 ${done}/${total}`;
      }else{
        el.textContent = '✨ AI 校对中…';
      }
      el.classList.add('show');
    }else{
      el.classList.remove('show');
    }
  }

  function buildAiBatchPrompt(contextStart, lastIdx, candidates){
    const lines = activeBook.parsedLines;
    const parts = [];
    for(let i = contextStart; i <= lastIdx; i++){
      const l = lines[i];
      if(l.type === 'narration'){
        parts.push(`旁白：${l.text}`);
      }else if(l._batchNo){
        parts.push(`第${l._batchNo}句 ？？？：“${l.text}”`);
      }else if(l.aiChecked || l.userFixed){
        parts.push(`${l.speaker || '未知'}：“${l.text}”`);
      }else{
        parts.push(`？？？：“${l.text}”`);
      }
    }
    const knownChars = activeBook.characters
      .filter(c => c && c.length >= 2 && c !== '？？？' && c !== '未知角色' && c !== '旁白')
      .join('、');
    return `你是一个小说阅读助手。请根据上下文，判断原文片段中每句【第N句 ？？？】的说话人是谁。
【书名】${activeBook.title}
【已知角色】${knownChars || '未知'}
【原文片段】（“旁白”是叙述；带名字的行是已确定的说话人）
${parts.join('\n')}
【要求】
只输出一个 JSON 数组，不要输出任何其他内容。每项格式：{"i": 编号, "name": "说话人"}，编号就是“第N句”中的 N。
说话人用角色名（2-4 个汉字）；若是新出现的角色，直接输出新角色的名字；实在无法判断时 name 输出“未知”。`;
  }

  function parseAiBatchResponse(raw){
    const results = [];
    try{
      const m = raw.match(/\[[\s\S]*\]/);
      const arr = JSON.parse(m ? m[0] : raw);
      if(Array.isArray(arr)){
        arr.forEach(it => {
          if(it && it.i !== undefined && typeof it.name === 'string'){
            results.push({ i: parseInt(it.i, 10), name: it.name.trim() });
          }
        });
      }
    }catch(e){
      const re = /"i"\s*:\s*(\d+)[^}]*?"name"\s*:\s*"([^"]+)"/g;
      let mm;
      while((mm = re.exec(raw))) results.push({ i: parseInt(mm[1], 10), name: mm[2].trim() });
    }
    return results;
  }

  // 把一条 AI 判断应用到数据 + 界面；返回是否真正改了说话人
  function aiApplyLineResult(lineData, aiSpeaker, book){
    aiSpeaker = (aiSpeaker || '').trim();
    aiSpeaker = stripSpeechSuffix(aiSpeaker);
    aiSpeaker = aiSpeaker.replace(/[“”"'`\n\r。，、：:！？!?\s]/g, '').trim();
    lineData.aiChecked = true;
    if(!aiSpeaker || aiSpeaker === '未知' || aiSpeaker === '？？？' || aiSpeaker.length > 5) return false;

    lineData.aiBy = true;
    const oldSpeaker = lineData.speaker || '';

    // AI 学习机制：把错误旧名拉黑 + 记录映射
    if(oldSpeaker && oldSpeaker !== aiSpeaker && oldSpeaker !== '？？？' && oldSpeaker !== '未知角色'){
      if(!learnData.denyWords.includes(oldSpeaker)){
        learnData.denyWords.push(oldSpeaker);
        saveLearn();
      }
      if(!book.nameFix) book.nameFix = {};
      book.nameFix[oldSpeaker] = aiSpeaker;
    }

    lineData.speaker = aiSpeaker;
    lineData.confidence = 'high';

    if(!book.characters.includes(aiSpeaker)){
      book.characters.push(aiSpeaker);
      if(activeBook === book) initRoleSelect();
    }

    // 这行已经显示在界面上时，实时更新气泡
    if(activeBook === book) updateLineDom(lineData, aiSpeaker);
    return true;
  }

  function updateLineDom(lineData, speaker){
    const bubble = messagesArea.querySelector(`.bubble[data-message-id="${lineData.id}"]`);
    if(!bubble) return;
    const row = bubble.closest('.message-row');
    if(row){
      row.dataset.speaker = speaker;
      row.classList.remove('left','right');
      row.classList.add(speaker === activeBook.myRole ? 'right' : 'left');
    }
    const nameSpan = bubble.querySelector('.character-name');
    if(nameSpan){
      nameSpan.textContent = speaker;
      nameSpan.classList.remove('low-conf');
      if(!nameSpan.querySelector('.ai-mark')){
        const mark = document.createElement('span');
        mark.className = 'ai-mark';
        mark.textContent = '✨';
        mark.title = 'AI 已校对说话人';
        nameSpan.appendChild(mark);
      }
    }
  }

  async function runAiBatch(){
    if(!activeBook || !aiConfig.enabled || !aiConfig.url || !aiConfig.key || !aiConfig.model) return;
    const book = activeBook;   // 固定本批对应的书，防止中途换书
    const wasSweep = aiSweepAll;
    const firstIdx = aiGetCandidates();
    if(firstIdx === -1) return;

    aiBusy = true;
    updateAiStatus();
    let candidates = [];
    let timeoutId = null;
    try{
      const lines = book.parsedLines;
      // 从 firstIdx 向后收集候选（最多 AI_BATCH 条，扫描不超过 80 行）
      let lastIdx = firstIdx;
      for(let i = firstIdx, scanned = 0; i < lines.length && scanned < 80; i++, scanned++){
        const l = lines[i];
        if(aiLineNeedsCheck(l)){
          l._batchNo = candidates.length + 1;
          candidates.push(l);
          lastIdx = i;
          if(candidates.length >= AI_BATCH) break;
        }
      }
      if(candidates.length === 0) return;

      const prompt = buildAiBatchPrompt(Math.max(0, firstIdx - AI_CONTEXT), lastIdx, candidates);
      const endpoint = aiConfig.url.replace(/\/+$/, '') + '/chat/completions';
      let content = '';
      for(let attempt = 0; attempt < 2; attempt++){
        const ctrl = new AbortController();
        timeoutId = setTimeout(()=>ctrl.abort(), 30000);
        const res = await fetch(endpoint, {
          method: 'POST',
          signal: ctrl.signal,
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + aiConfig.key
          },
          body: JSON.stringify({
            model: aiConfig.model,
            messages: [{ role: 'user', content: prompt + (attempt === 1 ? '\n\n再次强调：只输出 JSON 数组，不要任何解释。' : '') }],
            temperature: 0.1,
            max_tokens: 800
          })
        });
        clearTimeout(timeoutId);
        if(!res.ok) throw new Error('API 请求失败 (' + res.status + ')');
        const data = await res.json();
        content = (data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || '';
        if(parseAiBatchResponse(content).length > 0) break;
      }

      const results = parseAiBatchResponse(content);
      for(const r of results){
        const line = candidates[r.i - 1];
        if(line) aiApplyLineResult(line, r.name, book);
      }
      // 无论是否判断成功都标记已处理，避免重复请求；误判可用“重置本书校对”重来
      candidates.forEach(l => { l.aiChecked = true; delete l._batchNo; });
      saveLibrary();
      aiFailCount = 0;
    }catch(e){
      console.warn('AI 校对失败', e);
      candidates.forEach(l => { delete l._batchNo; });
      aiFailCount++;
      if(aiFailCount >= 3){
        aiPaused = true;
        toast('AI 校对连续失败已暂停，点击屏幕可自动重试');
      }
    }finally{
      if(timeoutId) clearTimeout(timeoutId);
      aiBusy = false;
      const hasNext = aiGetCandidates() !== -1;
      if(hasNext && !aiPaused){
        aiTimer = setTimeout(()=>{ aiTimer = null; runAiBatch(); }, AI_DEBOUNCE);
      }else if(wasSweep && !hasNext && aiConfig.enabled){
        toast('🎉 全书校对完成');
      }
      updateAiStatus();
    }
  }

  /* ============================================================
     渲染：进度 / 批注角标 / 气泡左右 / 角色下拉
     ============================================================ */
  function updateProgress(){
    if(!activeBook){ progressBadge.textContent = '0 / 0'; return; }
    const total = activeBook.parsedLines.length;
    progressBadge.textContent = `${activeBook.currentIndex} / ${total}`;
    if(total === 0){
      tapHint.innerHTML = '<span>点击 📂 导入书籍</span><span class="arrow">📂</span>';
    }else if(activeBook.currentIndex >= total){
      tapHint.innerHTML = '<span>📖 已读完，点击重新开始</span><span class="arrow">🔄</span>';
    }else{
      tapHint.innerHTML = '<span>点击屏幕，显示下一条</span><span class="arrow">⬇️</span>';
    }
  }

  function updateAnnoBadge(){
    if(!activeBook || !activeBook.annotations){ annoBadge.style.display = 'none'; return; }
    const count = Object.keys(activeBook.annotations).length;
    if(count > 0){
      annoBadge.textContent = count > 99 ? '99+' : count;
      annoBadge.style.display = 'inline-block';
    }else{ annoBadge.style.display = 'none'; }
  }

  function updateAllBubblesSide(){
    messagesArea.querySelectorAll('.message-row.dialogue').forEach(row=>{
      const speaker = resolveSpeaker(row.dataset.speaker);
      if(!speaker || !activeBook) return;
      row.classList.remove('left','right');
      row.classList.add(speaker === activeBook.myRole ? 'right' : 'left');
    });
  }

  function initRoleSelect(){
    if(!activeBook){ roleSelect.innerHTML = ''; return; }
    roleSelect.innerHTML = activeBook.characters.map(r =>
      `<option value="${r}" ${r === activeBook.myRole ? 'selected' : ''}>${r}</option>`
    ).join('');
    // 问题2：强制同步 DOM 当前值
    roleSelect.value = activeBook.myRole;
  }

  function shouldCollapse(lineData){
    if(!currentFilter) return false;
    if(lineData.type === 'narration') return false;
    const spk = resolveSpeaker(lineData.speaker);
    return spk !== currentFilter;
  }

  function createMessageElement(lineData){
    const { type, text, id } = lineData;
    const row = document.createElement('div');
    row.className = 'message-row';
    if(type === 'narration'){
      row.classList.add('narration');
      const bubble = document.createElement('div');
      bubble.className = 'bubble';
      bubble.textContent = text;
      bubble.dataset.messageId = id;
      if(lineData.isChapter) bubble.style.fontWeight = '600';
      row.appendChild(bubble);
      attachLongPress(bubble, text, id);
    }else{
      if(shouldCollapse(lineData)){
        row.classList.add('collapsed-row');
        const btn = document.createElement('div');
        btn.className = 'collapsed-btn';
        const spk = resolveSpeaker(lineData.speaker) || '（未命名）';
        btn.textContent = `（${spk} 说了一句，点击展开）`;
        btn.addEventListener('click', (e)=>{
          e.stopPropagation();
          currentFilter = null;
          renderFilterList();
          updateFilterBtn();
          rebuildMessages(activeBook.currentIndex);
          toast('已显示全部对话');
        });
        row.appendChild(btn);
        return row;
      }
      const speaker = lineData.speaker || '';
      const displaySpeaker = resolveSpeaker(speaker);
      row.classList.add('dialogue');
      row.dataset.speaker = speaker;
      row.classList.add(displaySpeaker === activeBook.myRole ? 'right' : 'left');
      const bubble = document.createElement('div');
      bubble.className = 'bubble';
      bubble.dataset.messageId = id;
      const nameSpan = document.createElement('span');
      nameSpan.className = 'character-name';
      nameSpan.textContent = displaySpeaker;
      if(lineData.confidence === 'low' && displaySpeaker){
        const q = document.createElement('span');
        q.className = 'low-conf';
        q.textContent = '?';
        q.title = '识别把握不大，请核对';
        nameSpan.appendChild(q);
      }
      nameSpan.title = '点击修正角色名';
      if(lineData.aiBy){
        const mark = document.createElement('span');
        mark.className = 'ai-mark';
        mark.textContent = '✨';
        mark.title = 'AI 已校对说话人';
        nameSpan.appendChild(mark);
      }
      nameSpan.addEventListener('click', (e)=>{
        e.stopPropagation();
        openFixModal(lineData, nameSpan, row);
      });
      bubble.appendChild(nameSpan);
      bubble.appendChild(document.createTextNode(text));
      row.appendChild(bubble);
      attachLongPress(bubble, text, id);
    }
    const bubbleEl = row.querySelector('.bubble');
    if(activeBook.annotations && activeBook.annotations[id]){
      bubbleEl.dataset.annotation = activeBook.annotations[id];
      bubbleEl.classList.add('annotated');
    }
    return row;
  }

  /* ============================================================
     改名 / 撤回（问题1、2、3）
     ============================================================ */
  function takeRenameSnapshot(desc){
    if(!activeBook) return;
    const snap = {
      bookId: activeBook.id,
      timestamp: Date.now(),
      desc: desc,
      data: JSON.parse(JSON.stringify({
        parsedLines: activeBook.parsedLines,
        characters: activeBook.characters,
        myRole: activeBook.myRole,
        aliases: activeBook.aliases,
        nameFix: activeBook.nameFix
      }))
    };
    renameHistory.push(snap);
    if(renameHistory.length > 20) renameHistory.shift();
    updateUndoBtn();
  }

  function updateUndoBtn(){
    if(!undoBtn) return;
    if(renameHistory.length > 0){ undoBtn.style.display = 'inline-block'; }
    else { undoBtn.style.display = 'none'; }
  }

  function undoRename(){
    if(renameHistory.length === 0){ toast('没有可撤回的操作'); return; }
    const snap = renameHistory.pop();
    const book = library.books.find(b => b.id === snap.bookId);
    if(!book){ toast('书不存在，无法撤回'); return; }

    book.parsedLines = snap.data.parsedLines;
    book.characters = snap.data.characters;
    book.myRole = snap.data.myRole;
    book.aliases = snap.data.aliases;
    book.nameFix = snap.data.nameFix;

    if(activeBook && activeBook.id === book.id){
      activeBook = book;
      initRoleSelect();
      rebuildMessages(activeBook.currentIndex);
      updateFilterBtn();
    }
    saveLibrary();
    renderShelf();
    toast(`已撤回：${snap.desc}`);
    updateUndoBtn();
  }

  // 纯数据层：改名 + 同步 myRole/aliases/nameFix + ABC→AB 二次清洗
  function renameSpeakerInData(book, oldName, newName) {
    if(!book || !newName || oldName === newName) return;
    book.parsedLines.forEach(l => {
      if(l.type === 'dialogue' && (l.speaker || '') === oldName) {
        l.speaker = newName;
        l.confidence = 'high';
      }
    });
    let charSet = new Set(book.characters);
    charSet.delete(oldName);
    charSet.add(newName);
    book.characters = [...charSet];

    // 问题2：myRole 同步 + 有效性校验
    if(book.myRole === oldName) book.myRole = newName;
    if(!book.characters.includes(book.myRole)){
      book.myRole = book.characters[0] || '未知角色';
    }

    // 问题2：aliases 同步
    if(book.aliases) {
      Object.keys(book.aliases).forEach(k => {
        if(book.aliases[k] === oldName) book.aliases[k] = newName;
        if(k === oldName) {
          book.aliases[newName] = book.aliases[oldName];
          delete book.aliases[oldName];
        }
      });
    }

    // 问题2：nameFix 同步
    if(book.nameFix) {
      Object.keys(book.nameFix).forEach(k => {
        if(book.nameFix[k] === oldName) book.nameFix[k] = newName;
      });
    }

    // 问题3：二次清洗，包含 newName 的 ABC 全部合并
    const finalChars = new Set();
    book.characters.forEach(c => {
      if(c !== newName && c.includes(newName) && c.length > newName.length){
        book.parsedLines.forEach(l => {
          if(l.type === 'dialogue' && l.speaker === c) l.speaker = newName;
        });
      } else {
        finalChars.add(c);
      }
    });
    finalChars.add(newName);
    book.characters = [...finalChars];
  }

  // 带 UI 刷新 + 撤回快照
  function renameSpeaker(oldName, newName) {
    if(!activeBook || !newName || oldName === newName) return;
    takeRenameSnapshot(`改名「${oldName}」→「${newName}」`);
    renameSpeakerInData(activeBook, oldName, newName);

    if(currentFilter === oldName) currentFilter = newName;

    saveLibrary();
    initRoleSelect();
    roleSelect.value = activeBook.myRole;      // 问题2：强制同步
    renderShelf();
    if(shelfModal.classList.contains('show')) {
      renderCharManage();
      renderFilterList();
    }
    rebuildMessages(activeBook.currentIndex);
    updateFilterBtn();
    renderFilterList();
  }

  /* ============================================================
     修正角色弹窗
     ============================================================ */
  function openFixModal(lineData, nameSpan, row){
    fixingLineData = lineData;
    fixingNameSpan = nameSpan;
    fixingRow = row;
    const oldName = lineData.speaker || '';
    fixOldName.textContent = oldName || '（空）';
    fixLowConf.textContent = lineData.confidence === 'low' ? '（低置信度）' : (lineData.confidence === 'medium' ? '（可能是这个人）' : '');
    fixNewName.value = '';
    fixNote.innerHTML = `输入正确角色名后：<br>「只改当前这条」= 只修正这一句；<br>「本书全部改」= 本书里所有「${oldName || '空'}」都改成新名字，且<b>后续章节遇到相同错词会自动修正</b>。`;
    fixModal.classList.add('show');
    modalOverlay.classList.add('show');
    setTimeout(()=>fixNewName.focus(), 200);
  }
  function closeFixModal(){
    fixModal.classList.remove('show');
    if(!document.querySelector('.sheet.show')) modalOverlay.classList.remove('show');
    fixingLineData = null; fixingNameSpan = null; fixingRow = null;
  }
  function doFix(mode){
    if(!fixingLineData) return;
    let newName = fixNewName.value.trim();
    if(!newName){ toast('请输入角色名'); return; }

    // 问题3：输入的名字若包含已知角色，自动归并
    const collapsed = collapseToKnown(newName, new Set(activeBook.characters));
    if(collapsed !== newName){
      newName = collapsed;
      toast(`已自动归并到「${newName}」`);
    }

    const oldName = fixingLineData.speaker || '';

    // 问题1：修改前存快照
    takeRenameSnapshot(mode === 'all'
      ? `全书改「${oldName||'空'}」→「${newName}」`
      : `改当前条「${oldName||'空'}」→「${newName}」`);

    if(oldName && oldName !== newName && oldName !== '？？？' && oldName !== '未知角色'){
      if(!learnData.denyWords.includes(oldName)){
        learnData.denyWords.push(oldName); saveLearn(); rebuildDenySet();
      }
      if(!activeBook.nameFix) activeBook.nameFix = {};
      activeBook.nameFix[oldName] = newName;

      if(oldName.length > newName.length && oldName.startsWith(newName)){
        const suffix = oldName.slice(newName.length);
        if(suffix.length >= 2) {
           if(!learnData.denyWords.includes(suffix)){
             learnData.denyWords.push(suffix);
             saveLearn(); rebuildDenySet();
           }
           const suffixRegex = new RegExp('([\\u4e00-\\u9fa5]{2,4})' + suffix);
           activeBook.parsedLines.forEach(l => {
             if(l.type === 'dialogue' && l.speaker && l.speaker.endsWith(suffix)){
               const match = l.speaker.match(suffixRegex);
               if(match) l.speaker = match[1];
             }
           });
        }
      }
    }

    if(mode === 'all'){
      let count = 0;
      activeBook.parsedLines.forEach(l=>{
        if(l.type === 'dialogue' && (l.speaker || '') === oldName){
          l.speaker = newName; l.confidence = 'high'; l.userFixed = true; count++;
        }
      });
      renameSpeaker(oldName, newName);
      toast(`本书 ${count} 条「${oldName || '空'}」已改为「${newName}」，已合并同名角色`);
    }else{
      fixingLineData.speaker = newName;
      fixingLineData.confidence = 'high';
      fixingLineData.userFixed = true;
      fixingNameSpan.textContent = newName;
      fixingRow.dataset.speaker = newName;
      fixingRow.classList.remove('left','right');
      fixingRow.classList.add(newName === activeBook.myRole ? 'right' : 'left');

      if(!activeBook.characters.includes(newName)) {
        activeBook.characters.push(newName);
        initRoleSelect();
      }
      saveLibrary(); renderShelf();
      toast(`已修正为「${newName}」`);
    }
    closeFixModal();
  }

  /* ============================================================
     消息推进
     ============================================================ */
  function showNextMessage(){
    if(!activeBook) return;
    if(activeBook.currentIndex >= activeBook.parsedLines.length) return;

    if(activeBook.currentIndex >= 3){
      tapHint.classList.add('fade-out');
    }

    const wasNearBottom = isNearBottom();
    const lineData = activeBook.parsedLines[activeBook.currentIndex];
    const msgEl = createMessageElement(lineData);
    messagesArea.appendChild(msgEl);

    if(aiConfig.enabled) scheduleAiCheck();

    if(wasNearBottom) scrollToBottom(true);
    activeBook.currentIndex++;
    updateProgress();
    if(activeBook.currentIndex >= activeBook.parsedLines.length && wasNearBottom) scrollToBottom(true);
    saveLibrary();
  }

  function rebuildMessages(count){
    messagesArea.innerHTML = '';
    if(!activeBook) return;
    for(let i=0;i<count && i<activeBook.parsedLines.length;i++){
      messagesArea.appendChild(createMessageElement(activeBook.parsedLines[i]));
    }
    updateProgress();
    if(count >= 3) tapHint.classList.add('fade-out');
    requestAnimationFrame(()=>scrollToBottom(false));
  }

  function restartReading(){
    if(!activeBook) return;
    messagesArea.innerHTML = '';
    activeBook.currentIndex = 0;
    activeBook.annotations = {};
    updateProgress(); updateAnnoBadge();
    tapHint.classList.remove('fade-out');
    if(activeBook.parsedLines.length > 0){
      messagesArea.appendChild(createMessageElement(activeBook.parsedLines[0]));
      activeBook.currentIndex = 1;
      updateProgress();
      scrollToBottom(false);
    }
    saveLibrary();
  }

  /* ============================================================
     长按批注
     ============================================================ */
  function attachLongPress(element, text, messageId){
    let pressTimer = null;
    let startX=0, startY=0;
    const startPress = (e)=>{
      if(e.type==='mousedown' && e.button!==0) return;
      if(e.type==='touchstart'){ const t=e.touches[0]; startX=t.clientX; startY=t.clientY; }
      else{ startX=e.clientX; startY=e.clientY; }
      pressTimer = setTimeout(()=>{
        window.__skipNextTap = true;
        openAnnotation(element, text, messageId);
        if(navigator.vibrate) navigator.vibrate(20);
      }, 550);
    };
    const cancelPress = ()=>{ if(pressTimer){clearTimeout(pressTimer);pressTimer=null;} };
    const moveHandler = (e)=>{
      if(!pressTimer) return;
      let cx,cy;
      if(e.type==='touchmove'){const t=e.touches[0];cx=t.clientX;cy=t.clientY;}
      else{cx=e.clientX;cy=e.clientY;}
      if(Math.hypot(cx-startX,cy-startY)>10){clearTimeout(pressTimer);pressTimer=null;}
    };
    element.addEventListener('mousedown', startPress);
    element.addEventListener('touchstart', startPress, {passive:true});
    element.addEventListener('mouseup', cancelPress);
    element.addEventListener('mouseleave', cancelPress);
    element.addEventListener('touchend', cancelPress);
    element.addEventListener('touchcancel', cancelPress);
    element.addEventListener('mousemove', moveHandler);
    element.addEventListener('touchmove', moveHandler, {passive:true});
    element.addEventListener('contextmenu', e=>e.preventDefault());
  }

  function openAnnotation(element, text, messageId){
    if(!activeBook) return;
    currentAnnotatingElement = element;
    currentAnnotatingId = messageId;
    currentAnnotatingText = text;
    const preview = text.length>70 ? text.slice(0,70)+'…' : text;
    annotationPreview.textContent = `“${preview}”`;
    annotationInput.value = (activeBook.annotations && activeBook.annotations[messageId]) || '';
    openSheet(annotationModal);
    setTimeout(()=>annotationInput.focus(), 300);
  }
  function closeAnnotation(){
    closeSheet(annotationModal);
    currentAnnotatingElement = null; currentAnnotatingId = null; currentAnnotatingText = '';
  }
  function saveAnnotation(){
    if(!activeBook || !currentAnnotatingElement || currentAnnotatingId === null) return;
    const val = annotationInput.value.trim();
    if(!activeBook.annotations) activeBook.annotations = {};
    if(val){
      activeBook.annotations[currentAnnotatingId] = val;
      currentAnnotatingElement.dataset.annotation = val;
      currentAnnotatingElement.classList.add('annotated');
    }else{
      delete activeBook.annotations[currentAnnotatingId];
      delete currentAnnotatingElement.dataset.annotation;
      currentAnnotatingElement.classList.remove('annotated');
    }
    saveLibrary(); updateAnnoBadge(); closeAnnotation();
  }
  function copyAnnotationText(){
    if(!currentAnnotatingText){ toast('没有可复制的文本'); return; }
    navigator.clipboard.writeText(currentAnnotatingText).then(()=>{
      toast('已复制原文');
    }).catch(()=>{
      const ta = document.createElement('textarea');
      ta.value = currentAnnotatingText;
      document.body.appendChild(ta); ta.select();
      try{ document.execCommand('copy'); toast('已复制原文'); }catch(e){ toast('复制失败'); }
      document.body.removeChild(ta);
    });
  }

  /* ============================================================
     批注总览
     ============================================================ */
  function openAnnoList(){
    if(!activeBook){ toast('请先导入书籍'); return; }
    const annos = activeBook.annotations || {};
    const ids = Object.keys(annos).map(Number).sort((a,b)=>a-b);
    if(ids.length === 0){
      annoList.innerHTML = '<div class="anno-empty">这本书还没有批注<br>长按任意气泡即可添加</div>';
      openSheet(annoListModal); return;
    }
    annoList.innerHTML = '';
    ids.forEach(id=>{
      const line = activeBook.parsedLines.find(l => l.id === id);
      if(!line) return;
      const quote = line.text.length > 50 ? line.text.slice(0,50)+'…' : line.text;
      const item = document.createElement('div');
      item.className = 'anno-item';
      const q = document.createElement('div'); q.className = 'anno-quote'; q.textContent = `「${quote}」`;
      const c = document.createElement('div'); c.className = 'anno-content'; c.textContent = annos[id];
      const meta = document.createElement('div'); meta.className = 'anno-meta';
      const pos = document.createElement('span');
      pos.textContent = `第 ${id+1} 条 · ${line.type==='dialogue' ? (resolveSpeaker(line.speaker) || '（空）') : '旁白'}`;
      const del = document.createElement('span'); del.className = 'anno-del'; del.textContent = '删除';
      del.addEventListener('click', (e)=>{
        e.stopPropagation();
        delete activeBook.annotations[id];
        saveLibrary(); updateAnnoBadge(); openAnnoList(); toast('批注已删除');
      });
      meta.appendChild(pos); meta.appendChild(del);
      item.appendChild(q); item.appendChild(c); item.appendChild(meta);
      item.addEventListener('click', ()=>{ closeSheet(annoListModal); jumpToMessage(id); });
      annoList.appendChild(item);
    });
    openSheet(annoListModal);
  }

  function jumpToMessage(targetId){
    if(!activeBook) return;
    if(targetId >= activeBook.currentIndex){
      activeBook.currentIndex = Math.min(targetId + 1, activeBook.parsedLines.length);
      rebuildMessages(activeBook.currentIndex);
    }
    const bubble = messagesArea.querySelector(`.bubble[data-message-id="${targetId}"]`);
    if(bubble){
      bubble.scrollIntoView({behavior:'smooth', block:'center'});
      bubble.classList.add('highlight-flash');
      setTimeout(()=>bubble.classList.remove('highlight-flash'), 1300);
    }
    saveLibrary();
    if(aiConfig.enabled) scheduleAiCheck();
  }

  /* ============================================================
     角色筛选
     ============================================================ */
  function updateFilterBtn(){
    if(currentFilter){ filterBtn.classList.add('active'); filterBtn.title = '只看：' + currentFilter; }
    else{ filterBtn.classList.remove('active'); filterBtn.title = '只看某人'; }
  }
  function renderFilterList(){
    if(!activeBook){ filterList.innerHTML = '<div class="empty-shelf">请先导入书籍</div>'; return; }
    filterList.innerHTML = '';
    const allBtn = document.createElement('div');
    allBtn.className = 'shelf-item' + (!currentFilter ? ' active' : '');
    allBtn.innerHTML = `<div class="shelf-item-info"><div class="shelf-item-title">显示全部</div><div class="shelf-item-meta">不筛选</div></div>`;
    allBtn.addEventListener('click', ()=>{
      currentFilter = null; updateFilterBtn();
      rebuildMessages(activeBook.currentIndex);
      renderFilterList(); closeSheet(filterModal);
    });
    filterList.appendChild(allBtn);
    activeBook.characters.forEach(ch=>{
      const item = document.createElement('div');
      item.className = 'shelf-item' + (currentFilter === ch ? ' active' : '');
      const count = activeBook.parsedLines.filter(l => l.type==='dialogue' && resolveSpeaker(l.speaker) === ch).length;
      item.innerHTML = `<div class="shelf-item-info"><div class="shelf-item-title">${ch}</div><div class="shelf-item-meta">${count} 条对话</div></div>`;
      item.addEventListener('click', ()=>{
        currentFilter = ch; updateFilterBtn();
        rebuildMessages(activeBook.currentIndex);
        renderFilterList(); closeSheet(filterModal);
      });
      filterList.appendChild(item);
    });
  }

  /* ============================================================
     导出
     ============================================================ */
  function downloadBlob(content, filename, type){
    const blob = new Blob([content], {type: type || 'text/plain;charset=utf-8'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click();
    document.body.removeChild(a);
    setTimeout(()=>URL.revokeObjectURL(url), 1000);
  }
  function exportBook(){
    if(!activeBook){ toast('请先导入书籍'); return; }
    let out = '';
    for(const l of activeBook.parsedLines){
      if(l.type === 'narration') out += l.text + '\n';
      else out += (resolveSpeaker(l.speaker) || '（未命名）') + '：' + l.text + '\n';
    }
    downloadBlob(out, activeBook.title + '_对话.txt');
    toast('已导出本书');
  }
  function exportAnnotations(){
    if(!activeBook){ toast('请先导入书籍'); return; }
    const annos = activeBook.annotations || {};
    const ids = Object.keys(annos).map(Number).sort((a,b)=>a-b);
    if(ids.length === 0){ toast('这本书还没有批注'); return; }
    let out = `# ${activeBook.title} · 批注\n\n`;
    ids.forEach(id=>{
      const line = activeBook.parsedLines.find(l => l.id === id);
      if(!line) return;
      const spk = line.type === 'dialogue' ? (resolveSpeaker(line.speaker) || '（空）') : '旁白';
      out += `## 第 ${id+1} 条 · ${spk}\n\n> ${line.text}\n\n${annos[id]}\n\n---\n\n`;
    });
    downloadBlob(out, activeBook.title + '_批注.md', 'text/markdown;charset=utf-8');
    toast('已导出批注');
  }

  /* ============================================================
     别名 & 角色管理
     ============================================================ */
  function renderAliasList(){
    if(!activeBook){ aliasList.innerHTML = '<div class="empty-shelf">请先导入书籍</div>'; return; }
    if(!activeBook.aliases) activeBook.aliases = {};
    const entries = Object.entries(activeBook.aliases);
    if(entries.length === 0){ aliasList.innerHTML = '<div class="small-hint">还没有别名映射。</div>'; return; }
    aliasList.innerHTML = '';
    entries.forEach(([from, to])=>{
      const item = document.createElement('div');
      item.className = 'alias-item';
      const main = document.createElement('span'); main.className = 'alias-main'; main.textContent = to;
      const sub = document.createElement('span'); sub.className = 'alias-sub'; sub.textContent = '← ' + from;
      const del = document.createElement('span'); del.className = 'alias-del'; del.textContent = '✕'; del.title = '删除';
      del.addEventListener('click', ()=>{
        delete activeBook.aliases[from];
        saveLibrary(); renderAliasList(); initRoleSelect();
        rebuildMessages(activeBook.currentIndex);
      });
      item.appendChild(sub); item.appendChild(main); item.appendChild(del);
      aliasList.appendChild(item);
    });
  }

  function renderCharManage(){
    if(!activeBook){ charManageList.innerHTML = '<div class="empty-shelf">请先导入书籍</div>'; return; }
    charManageList.innerHTML = '';
    if(activeBook.characters.length === 0){
      charManageList.innerHTML = '<div class="small-hint">本书暂无角色。</div>';
      return;
    }
    activeBook.characters.forEach(ch => {
      const count = activeBook.parsedLines.filter(l => l.type==='dialogue' && resolveSpeaker(l.speaker) === ch).length;
      const item = document.createElement('div');
      item.className = 'char-manage-item';
      item.innerHTML = `<div><span class="char-manage-name">${ch}</span><span class="char-manage-count">${count}条</span></div>`;
      const btn = document.createElement('button');
      btn.className = 'char-manage-edit';
      btn.textContent = '改名';
      btn.addEventListener('click', () => {
        const newName = prompt(`把本书所有「${ch}」改成：`, ch);
        if(newName && newName.trim() && newName.trim() !== ch){
          renameSpeaker(ch, newName.trim());
          toast(`已将「${ch}」全局合并改名为「${newName.trim()}」`);
        }
      });
      item.appendChild(btn);
      charManageList.appendChild(item);
    });
  }

  function cleanupCharacters(){
    if(!activeBook) return;
    let toRemove = [];
    const charsSnapshot = [...activeBook.characters];
    for(let i = 0; i < charsSnapshot.length; i++) {
      const str = charsSnapshot[i];
      if(str.length < 3) continue;
      for(const base of charsSnapshot) {
        if(base !== str && str.includes(base)) {
          toRemove.push({ old: str, new: base });
          break;
        }
      }
    }
    if(toRemove.length === 0) {
      toast('没有找到包含已知角色的错词，列表很干净。');
      return;
    }
    if(confirm(`发现 ${toRemove.length} 个错词（如“柯寻回”包含“柯寻”）。\n是否将它们自动合并回原本的短名字？`)) {
      takeRenameSnapshot('一键清理错词');
      toRemove.forEach(item => {
        renameSpeakerInData(activeBook, item.old, item.new);
      });
      saveLibrary(); initRoleSelect(); renderShelf();
      if(shelfModal.classList.contains('show')) { renderCharManage(); renderFilterList(); }
      rebuildMessages(activeBook.currentIndex); updateFilterBtn();
      toast(`已成功合并 ${toRemove.length} 个错词到对应角色`);
    }
  }

  /* ============================================================
     书架
     ============================================================ */
  function renderShelf(){
    if(library.books.length === 0){
      shelfList.innerHTML = '<div class="empty-shelf">书架还是空的<br>点 📂 导入你的第一本书吧</div>';
    }else{
      shelfList.innerHTML = '';
      library.books.forEach(book=>{
        const item = document.createElement('div');
        item.className = 'shelf-item' + (activeBook && book.id === activeBook.id ? ' active' : '');
        const info = document.createElement('div'); info.className = 'shelf-item-info';
        const title = document.createElement('div'); title.className = 'shelf-item-title'; title.textContent = book.title;
        const meta = document.createElement('div'); meta.className = 'shelf-item-meta';
        const total = book.parsedLines.length;
        const chCount = book.chapters ? book.chapters.length : 0;
        const annoCount = book.annotations ? Object.keys(book.annotations).length : 0;
        const lowCount = book.parsedLines.filter(l => l.type==='dialogue' && l.confidence === 'low').length;
        const unknownCount = book.parsedLines.filter(l => l.type==='dialogue' && l.speaker === '？？？').length;
        meta.textContent = `${book.currentIndex}/${total} 条 · ${book.characters.length} 角色 · ${chCount} 章${annoCount ? ' · 📝'+annoCount : ''}${lowCount ? ' · ⚠️'+lowCount : ''}${unknownCount ? ' · ❓'+unknownCount : ''} · ⏱ ${formatTime(book.readTime || 0)}`;
        info.appendChild(title); info.appendChild(meta);
        const actions = document.createElement('div'); actions.className = 'shelf-item-actions';
        const del = document.createElement('button'); del.className = 'mini-btn danger'; del.textContent = '删除';
        del.addEventListener('click', (e)=>{
          e.stopPropagation();
          if(confirm(`确定删除《${book.title}》？进度和批注都会丢失。`)){
            library.books = library.books.filter(b=>b.id !== book.id);
            if(activeBook && activeBook.id === book.id){
              activeBook = null; setActiveId(''); messagesArea.innerHTML = '';
              bookTitleEl.textContent = '📖 未导入书籍'; roleSelect.innerHTML = '';
              updateProgress(); updateAnnoBadge(); stopReadTimer();
            }
            saveLibrary(); renderShelf(); toast('已删除');
          }
        });
        actions.appendChild(del);
        item.appendChild(info); item.appendChild(actions);
        item.addEventListener('click', ()=>{ openBook(book.id); closeAllSheets(); });
        shelfList.appendChild(item);
      });
    }
    const learnedCount = learnData.denyWords.length;
    const fixCount = activeBook && activeBook.nameFix ? Object.keys(activeBook.nameFix).length : 0;
    learnStats.innerHTML = `全局否决词：<b>${learnedCount}</b> 个（跨书生效，防误判）。<br>本书学习映射：<b>${fixCount}</b> 个（重新解析本书时生效）。`;
    renderAliasList();
    renderCharManage();
  }

  function openBook(id){
    const book = library.books.find(b=>b.id === id);
    if(!book) return;
    stopReadTimer();
    activeBook = book;
    if(!activeBook.nameFix) activeBook.nameFix = {};
    if(!activeBook.annotations) activeBook.annotations = {};
    if(!activeBook.aliases) activeBook.aliases = {};
    if(!activeBook.readTime) activeBook.readTime = 0;
    setActiveId(id); currentFilter = null; aiSweepAll = false; updateFilterBtn();
    bookTitleEl.textContent = '📖 ' + book.title;
    initRoleSelect(); rebuildMessages(book.currentIndex); updateAnnoBadge(); renderShelf(); renderAliasList();
    minLenInput.value = settings.minLen; maxLenInput.value = settings.maxLen;
    startReadTimer();
    if(aiConfig.enabled) scheduleAiCheck(true);
  }

  /* ============================================================
     章节目录
     ============================================================ */
  function openChapterModal(){
    if(!activeBook) return;
    const chapters = activeBook.chapters || [];
    if(chapters.length === 0){
      chapterList.innerHTML = '<div class="empty-shelf">这本书没有识别到章节标题<br>（需要“第X章”“Chapter N”“序章”等格式）</div>';
      openSheet(chapterModal); return;
    }
    chapterList.innerHTML = '';
    let currentChapterIdx = -1;
    for(let i=0;i<chapters.length;i++){
      if(chapters[i].startIndex <= activeBook.currentIndex) currentChapterIdx = i;
      else break;
    }
    chapters.forEach((ch, idx)=>{
      const el = document.createElement('div');
      el.className = 'chapter-item' + (idx === currentChapterIdx ? ' here' : '');
      const t = document.createElement('span'); t.className = 'ch-title'; t.textContent = ch.title;
      const p = document.createElement('span'); p.className = 'ch-pos'; p.textContent = `第${ch.startIndex + 1}条`;
      el.appendChild(t); el.appendChild(p);
      el.addEventListener('click', ()=>{ jumpToChapter(idx); closeSheet(chapterModal); });
      chapterList.appendChild(el);
    });
    openSheet(chapterModal);
  }
  function jumpToChapter(chapterIdx){
    if(!activeBook || !activeBook.chapters || !activeBook.chapters[chapterIdx]) return;
    const startIdx = activeBook.chapters[chapterIdx].startIndex;
    const upTo = Math.min(startIdx + 1, activeBook.parsedLines.length);
    messagesArea.innerHTML = '';
    for(let i=0;i<upTo;i++) messagesArea.appendChild(createMessageElement(activeBook.parsedLines[i]));
    activeBook.currentIndex = upTo; updateProgress();
    const bubble = messagesArea.querySelector(`.bubble[data-message-id="${startIdx}"]`);
    if(bubble){
      bubble.scrollIntoView({behavior:'smooth', block:'center'});
      bubble.classList.add('highlight-flash');
      setTimeout(()=>bubble.classList.remove('highlight-flash'), 1300);
    }else{ scrollToBottom(false); }
    saveLibrary(); toast('已跳到：' + activeBook.chapters[chapterIdx].title.slice(0,20));
    if(aiConfig.enabled) scheduleAiCheck();
  }

  /* ============================================================
     导入
     ============================================================ */
  function openImport(){ importTitle.value = ''; importTextarea.value = ''; fileInput.value = ''; openSheet(importModal); }
  function closeImport(){ closeSheet(importModal); }

  function doImport(text, titleInput){
    if(!text || !text.trim()){ toast('内容为空，请先导入或粘贴书籍文本'); return; }
    const { parsedLines, characters, chapters } = parseBook(text, {});
    let title = (titleInput || '').trim();
    if(!title){
      if(chapters.length > 0) title = chapters[0].title.slice(0, 20);
      else title = text.trim().split('\n')[0].trim().slice(0, 20) || '未命名书籍';
    }
    const book = {
      id: genId(), title, parsedLines, characters, chapters,
      nameFix: {}, aliases: {}, myRole: characters[0] || '未知角色',
      currentIndex: 0, annotations: {}, readTime: 0, aiV2: true
    };
    if(book.parsedLines.length > 0) book.currentIndex = 1;
    library.books.push(book); saveLibrary(); closeImport(); openBook(book.id);
    const lowCount = parsedLines.filter(l => l.type==='dialogue' && l.confidence==='low').length;
    const unknownCount = parsedLines.filter(l => l.type==='dialogue' && l.speaker==='？？？').length;
    toast(`导入成功！共 ${parsedLines.length} 条${unknownCount ? '，'+unknownCount+' 条未识别' : ''}${lowCount ? '，'+lowCount+' 条低置信度' : ''}`);
  }

  /* ============================================================
     存档
     ============================================================ */
  function exportArchive(){
    if(library.books.length === 0 && learnData.denyWords.length === 0){ toast('没有可导出的数据'); return; }
    const data = { app:'chatReader', version:30, exportedAt:new Date().toISOString(), library, learn:learnData, settings };
    downloadBlob(JSON.stringify(data, null, 2), `小说阅读器存档_${new Date().toISOString().slice(0,10).replace(/-/g,'')}.json`, 'application/json');
    toast('存档已导出');
  }
  function importArchive(file){
    const reader = new FileReader();
    reader.onload = (ev)=>{
      try{
        const data = JSON.parse(ev.target.result);
        if(!data.library || !Array.isArray(data.library.books)){ toast('文件格式不正确'); return; }
        const incoming = data.library.books;
        const ok = confirm(`存档中有 ${incoming.length} 本书${data.learn && data.learn.denyWords ? '，以及学习记录' : ''}。\n\n点"确定"合并到现有书架（同 id 覆盖）\n点"取消"放弃导入`);
        if(!ok) return;
        const map = new Map(library.books.map(b=>[b.id, b]));
        incoming.forEach(b=>{
          if(!b.nameFix) b.nameFix = {};
          if(!b.annotations) b.annotations = {};
          if(!b.aliases) b.aliases = {};
          if(!b.readTime) b.readTime = 0;
          b.parsedLines.forEach(l=>{ if(l.type==='dialogue' && !l.confidence) l.confidence = 'high'; });
          migrateLegacyAiMarks(b);
          map.set(b.id, b);
        });
        library.books = [...map.values()];
        if(data.learn && Array.isArray(data.learn.denyWords)){
          data.learn.denyWords.forEach(w=>{ if(!learnData.denyWords.includes(w)) learnData.denyWords.push(w); });
          saveLearn(); rebuildDenySet();
        }
        if(data.settings){
          if(typeof data.settings.minLen === 'number') settings.minLen = data.settings.minLen;
          if(typeof data.settings.maxLen === 'number') settings.maxLen = data.settings.maxLen;
          saveSettings();
        }
        saveLibrary();
        if(!activeBook && library.books.length > 0){ openBook(library.books[0].id); }
        else if(activeBook){
          const fresh = library.books.find(b=>b.id === activeBook.id);
          if(fresh){ activeBook = fresh; rebuildMessages(activeBook.currentIndex); }
        }
        renderShelf(); toast(`导入成功，共 ${incoming.length} 本`);
      }catch(e){ toast('解析失败，文件可能损坏'); }
    };
    reader.readAsText(file, 'UTF-8');
  }

  /* ============================================================
     初始化
     ============================================================ */
  async function initApp(){
    // 1. 异步加载数据库
    await initDB();
    await loadStorage();
    rebuildDenySet();
    minLenInput.value = settings.minLen; maxLenInput.value = settings.maxLen;

    // 2. 恢复界面
    if(activeBook){
      if(!activeBook.nameFix) activeBook.nameFix = {};
      if(!activeBook.annotations) activeBook.annotations = {};
      if(!activeBook.aliases) activeBook.aliases = {};
      if(!activeBook.readTime) activeBook.readTime = 0;
      activeBook.parsedLines.forEach(l=>{ if(l.type==='dialogue' && !l.confidence) l.confidence = 'high'; });
      bookTitleEl.textContent = '📖 ' + activeBook.title;
      initRoleSelect(); rebuildMessages(activeBook.currentIndex); updateAnnoBadge();
      startReadTimer();
      if(aiConfig.enabled) scheduleAiCheck(true);
    } else {
      bookTitleEl.textContent = '📖 未导入书籍';
      tapHint.innerHTML = '<span>点击 📂 导入书籍</span><span class="arrow">📂</span>';
    }
    updateUndoBtn();

    // 3. 绑定 AI 设置事件
    function updateAiBtn(){
      if(aiConfig.enabled && aiConfig.key) aiBtn.style.color = '#a05b4b';
      else aiBtn.style.color = '#6a4c93';
    }
    updateAiBtn();

    aiBtn.addEventListener('click', (e)=>{
      e.stopPropagation();
      aiUrl.value = aiConfig.url;
      aiKey.value = aiConfig.key;
      aiModel.value = aiConfig.model;
      aiEnable.checked = aiConfig.enabled;
      aiScope.value = aiConfig.scope || 'all';
      openSheet(aiModal);
    });
    aiClose.addEventListener('click', ()=>{ closeSheet(aiModal); });
    aiCancel.addEventListener('click', ()=>{ closeSheet(aiModal); });
    aiSave.addEventListener('click', ()=>{
      aiConfig.url = aiUrl.value.trim();
      aiConfig.key = aiKey.value.trim();
      aiConfig.model = aiModel.value.trim();
      aiConfig.scope = aiScope.value === 'uncertain' ? 'uncertain' : 'all';
      aiConfig.enabled = aiEnable.checked;
      saveAiConfig();
      updateAiBtn();
      if(!aiConfig.enabled && aiTimer){ clearTimeout(aiTimer); aiTimer = null; }
      updateAiStatus();
      closeSheet(aiModal);
      toast('AI 设置已保存');
      if(aiConfig.enabled && activeBook) scheduleAiCheck(true);
    });
    aiCheckAllBtn.addEventListener('click', (e)=>{
      e.stopPropagation();
      if(!activeBook){ toast('请先导入书籍'); return; }
      if(!aiConfig.enabled || !aiConfig.url || !aiConfig.key || !aiConfig.model){
        toast('请先启用并填写 AI 设置');
        return;
      }
      aiSweepAll = true;
      aiPaused = false;
      aiFailCount = 0;
      updateAiStatus();
      scheduleAiCheck(true);
      closeSheet(aiModal);
    });
    aiResetBtn.addEventListener('click', (e)=>{
      e.stopPropagation();
      if(!activeBook){ toast('请先导入书籍'); return; }
      activeBook.parsedLines.forEach(l=>{
        if(l.type === 'dialogue' && !l.userFixed) l.aiChecked = false;
      });
      saveLibrary();
      toast('已重置本书 AI 校对标记');
      if(aiConfig.enabled) scheduleAiCheck(true);
    });

    // 4. 角色下拉
    roleSelect.addEventListener('change', (e)=>{
      if(!activeBook) return;
      activeBook.myRole = e.target.value;
      updateAllBubblesSide(); saveLibrary();
    });

    // 5. 撤回按钮
    undoBtn.addEventListener('click', (e)=>{
      e.stopPropagation();
      undoRename();
    });

    // 6. 主点击推进
    document.getElementById('chatContainer').addEventListener('click', (e)=>{
      if(e.target.closest('.role-selector')) return;
      if(e.target.closest('.sheet')) return;
      if(e.target.closest('.modal-overlay')) return;
      if(e.target.closest('.fix-modal')) return;
      if(e.target.closest('#backToLatest')) return;
      if(e.target.closest('#importBtn')) return;
      if(e.target.closest('#shelfBtn')) return;
      if(e.target.closest('#annoBtn')) return;
      if(e.target.closest('#filterBtn')) return;
      if(e.target.closest('#aiBtn')) return;
      if(e.target.closest('#undoBtn')) return;
      if(e.target.closest('#bookTitle')) return;
      if(e.target.closest('#progressBadge')) return;
      if(e.target.closest('.character-name')) return;
      if(window.__skipNextTap){ window.__skipNextTap = false; return; }

      if(!activeBook){ openImport(); return; }
      if(activeBook.currentIndex >= activeBook.parsedLines.length){ restartReading(); }
      else { showNextMessage(); }
    });

    backToLatest.addEventListener('click', (e)=>{ e.stopPropagation(); scrollToBottom(true); });
    messagesArea.addEventListener('scroll', ()=>{
      if(isNearBottom()) backToLatest.classList.remove('show');
      else backToLatest.classList.add('show');
    }, {passive:true});

    // 7. 批注面板
    annotationClose.addEventListener('click', closeAnnotation);
    annotationCancel.addEventListener('click', closeAnnotation);
    annotationSave.addEventListener('click', saveAnnotation);
    annotationCopy.addEventListener('click', copyAnnotationText);
    annotationModal.addEventListener('click', e=>e.stopPropagation());

    // 8. 遮罩点击
    modalOverlay.addEventListener('click', ()=>{
      closeAnnotation(); closeImport();
      shelfModal.classList.remove('show'); chapterModal.classList.remove('show');
      annoListModal.classList.remove('show'); filterModal.classList.remove('show');
      aiModal.classList.remove('show');
      closeFixModal(); modalOverlay.classList.remove('show');
    });

    // 9. 导入
    importBtn.addEventListener('click', (e)=>{ e.stopPropagation(); openImport(); });
    importClose.addEventListener('click', closeImport);
    importCancel.addEventListener('click', closeImport);
    importModal.addEventListener('click', e=>e.stopPropagation());
    importConfirm.addEventListener('click', ()=>{ doImport(importTextarea.value, importTitle.value); });

    fileInput.addEventListener('change', async (e)=>{
      const f = e.target.files[0];
      if(!f) return;
      try{
        const forced = encodingSelect.value;
        const result = await readTextFileSmart(f, forced);
        importTextarea.value = result.text;
        if(!importTitle.value) importTitle.value = f.name.replace(/\.txt$/i, '');
        toast(`已读取（编码：${result.encoding}），点"导入并阅读"生效`);
      }catch(err){ toast('读取失败：' + err.message); }
    });

    // 10. 书架
    shelfBtn.addEventListener('click', (e)=>{ e.stopPropagation(); renderShelf(); openSheet(shelfModal); });
    shelfClose.addEventListener('click', ()=>{ closeSheet(shelfModal); });
    shelfModal.addEventListener('click', e=>e.stopPropagation());
    bookTitleEl.addEventListener('click', (e)=>{ e.stopPropagation(); renderShelf(); openSheet(shelfModal); });

    cleanupBtn.addEventListener('click', (e) => { e.stopPropagation(); cleanupCharacters(); });

    // 11. 章节
    chapterClose.addEventListener('click', ()=>{ closeSheet(chapterModal); });
    chapterModal.addEventListener('click', e=>e.stopPropagation());
    progressBadge.addEventListener('click', (e)=>{
      e.stopPropagation();
      if(!activeBook){ toast('请先导入书籍'); return; }
      openChapterModal();
    });

    // 12. 批注总览
    annoBtn.addEventListener('click', (e)=>{ e.stopPropagation(); openAnnoList(); });
    annoListClose.addEventListener('click', ()=>{ closeSheet(annoListModal); });
    annoListModal.addEventListener('click', e=>e.stopPropagation());

    // 13. 筛选
    filterBtn.addEventListener('click', (e)=>{
      e.stopPropagation();
      if(!activeBook){ toast('请先导入书籍'); return; }
      renderFilterList(); openSheet(filterModal);
    });
    filterClose.addEventListener('click', ()=>{ closeSheet(filterModal); });
    filterModal.addEventListener('click', e=>e.stopPropagation());
    filterClear.addEventListener('click', ()=>{
      currentFilter = null; updateFilterBtn();
      if(activeBook) rebuildMessages(activeBook.currentIndex);
      closeSheet(filterModal);
    });

    // 14. 导出 / 存档
    exportBtn.addEventListener('click', (e)=>{ e.stopPropagation(); exportArchive(); });
    exportBookBtn.addEventListener('click', (e)=>{ e.stopPropagation(); exportBook(); });
    exportAnnoBtn.addEventListener('click', (e)=>{ e.stopPropagation(); exportAnnotations(); });
    importArchiveInput.addEventListener('change', (e)=>{
      const f = e.target.files[0];
      if(!f) return;
      importArchive(f); e.target.value = '';
    });

    // 15. 学习清空
    clearLearnBtn.addEventListener('click', (e)=>{
      e.stopPropagation();
      if(confirm('确定清空全局否决词？已导入的书和本书映射不受影响，但下次解析新书时误判词会重新出现。')){
        learnData = { denyWords: [] }; saveLearn(); rebuildDenySet(); renderShelf(); toast('全局否决词已清空');
      }
    });

    // 16. 旁白拆分参数
    minLenInput.addEventListener('change', ()=>{
      const v = parseInt(minLenInput.value, 10);
      if(!isNaN(v) && v >= 2 && v <= 50){ settings.minLen = v; saveSettings(); }
    });
    maxLenInput.addEventListener('change', ()=>{
      const v = parseInt(maxLenInput.value, 10);
      if(!isNaN(v) && v >= 10 && v <= 120){ settings.maxLen = v; saveSettings(); }
    });

    // 17. 别名添加
    aliasAddBtn.addEventListener('click', ()=>{
      if(!activeBook){ toast('请先导入书籍'); return; }
      const from = aliasFrom.value.trim();
      const to = aliasTo.value.trim();
      if(!from || !to){ toast('别名和主名都要填'); return; }
      if(from === to){ toast('别名和主名不能相同'); return; }
      if(!activeBook.aliases) activeBook.aliases = {};
      activeBook.aliases[from] = to;
      aliasFrom.value = ''; aliasTo.value = '';
      saveLibrary(); renderAliasList(); initRoleSelect(); renderShelf();
      rebuildMessages(activeBook.currentIndex);
      toast(`已添加别名：${from} → ${to}`);
    });

    // 18. 改名弹窗按钮
    fixCancel.addEventListener('click', closeFixModal);
    fixThisOnly.addEventListener('click', ()=>doFix('one'));
    fixAllInBook.addEventListener('click', ()=>doFix('all'));
    fixNewName.addEventListener('keydown', (e)=>{
      if(e.key === 'Enter'){ e.preventDefault(); doFix('one'); }
    });
    fixModal.addEventListener('click', e=>e.stopPropagation());
  }

  // 执行启动
  initApp();
})();